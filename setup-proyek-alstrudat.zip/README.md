# alstrudat-c01-ifs18005

## Compile

`mvn clean package`

## Run

`java -cp target/app.jar del.alstrudat.App`