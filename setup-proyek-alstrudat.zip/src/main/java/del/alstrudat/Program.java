package del.alstrudat;

public class Program {

  public static void printInfo(String name, int age) {
    // Print the name and age of the person
  }
}
